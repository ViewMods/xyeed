#pragma once

// WE SUPPORT FUN  (4.6.0) SDKGen by @O_N_E_B_I_E_C_E | @onebiecerr 
// Send Message Me For SDKGen Tool  
// Generate on Tue Sep  8 20:36:06 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// AnimBlueprintGeneratedClass ABP_PetSpectator_MiniTV.ABP_PetSpectator_MiniTV_C
// 0x0C90 (0x1120 - 0x0490)
class UABP_PetSpectator_MiniTV_C : public USTExtraPetSpectatorAnimInstance
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0490(0x0008) (Transient, DuplicateTransient)
	struct FAnimNode_Root                              AnimGraphNode_Root_EA5F48AC4A9F1CDE36CB2EBB250A0264;      // 0x0498(0x0050)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C853458A4AEAB1DFEBD030A8777435DA;// 0x04E8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_09CBF0C2430CDE8E97F93EAD20C39DE8;// 0x0530(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_BB985D224535509A38C4F6859AA2877E;// 0x0578(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_CDBB51A0489CC99483DCB8B3DAC2D417;// 0x05C0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D52967AE43174A92130032A375F2B388;// 0x0608(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_17992ABD43AE90C6C2B8DB98581A1252;// 0x0650(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_945732AB4D14124001B5A1BA5E44564E;// 0x0698(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D8AE1180459B4505531C57849656954B;// 0x06E0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_F4BA0C0048749CF23EAD25A7E526522A;// 0x0728(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_7F1FBFFB47979AF90A80D68AEAD0FAD4;// 0x0770(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A6A6B59445A47D5422694A914F8E5C78;// 0x07B8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_DDEBC5974DF4F3699C0679945890537D;// 0x0800(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_132BBF0A411F5961E82854B519BA0E9B;// 0x0848(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A561C51E4A4F43C0DF3DF482E5CD13EB;// 0x0890(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_4AE760824BD6017B891F9B9406DE7A28;// 0x08D8(0x0048)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_6EED9F444DC544725BC9548E0D11B4BB2;// 0x0920(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6570CCC046F4DAC94E5E91B4B85EED062;// 0x0990(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_6EED9F444DC544725BC9548E0D11B4BB;// 0x09E0(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6570CCC046F4DAC94E5E91B4B85EED06;// 0x0A50(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_FE6EAEF84DDE4FD80ECD48950A8E3505;// 0x0AA0(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_34B1E2574975F125F97E97ACEC9F97BD;// 0x0B10(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_2DF76C5B486E4CBCFF76528BEC8EC694;// 0x0B60(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_2F60C24C469A03CDA9C170B428307C95;// 0x0BD0(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_5659CC3E44CBC29E51C86E91AC437612;// 0x0C20(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_5B458A5140F491F5105924BD9F3133B9;// 0x0C90(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_9090A73B44EDC2B417C8D6B3ECE24926;// 0x0CE0(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_501FF711462B68208994E480E9D2764B;// 0x0D50(0x0050)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_69B91A6443D64CADF3F57680FF0811F0;// 0x0DA0(0x0128)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_D7BB27CD4BB1F1BECB8D91B23643B57E;// 0x0EC8(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_FFBD6F1747CE9D75FE325083333BCE10;// 0x0F18(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_F20798C841C3FCA117794BAB32C53B34;// 0x0F88(0x0050)
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_0E5A2CAD45E0A10D749D578F75728A65;// 0x0FD8(0x00D8)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_D8750C904C9FF6BD0DEB70866AB9DC29;      // 0x10B0(0x0070)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass ABP_PetSpectator_MiniTV.ABP_PetSpectator_MiniTV_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_D8AE1180459B4505531C57849656954B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_945732AB4D14124001B5A1BA5E44564E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_F4BA0C0048749CF23EAD25A7E526522A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_7F1FBFFB47979AF90A80D68AEAD0FAD4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_A6A6B59445A47D5422694A914F8E5C78();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_17992ABD43AE90C6C2B8DB98581A1252();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_DDEBC5974DF4F3699C0679945890537D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_132BBF0A411F5961E82854B519BA0E9B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_A561C51E4A4F43C0DF3DF482E5CD13EB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_4AE760824BD6017B891F9B9406DE7A28();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_D52967AE43174A92130032A375F2B388();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_6EED9F444DC544725BC9548E0D11B4BB_1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_6EED9F444DC544725BC9548E0D11B4BB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_CDBB51A0489CC99483DCB8B3DAC2D417();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_FE6EAEF84DDE4FD80ECD48950A8E3505();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_2DF76C5B486E4CBCFF76528BEC8EC694();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_BB985D224535509A38C4F6859AA2877E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_5659CC3E44CBC29E51C86E91AC437612();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_9090A73B44EDC2B417C8D6B3ECE24926();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_09CBF0C2430CDE8E97F93EAD20C39DE8();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_BlendSpacePlayer_69B91A6443D64CADF3F57680FF0811F0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_SequencePlayer_FFBD6F1747CE9D75FE325083333BCE10();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_PetSpectator_MiniTV_AnimGraphNode_TransitionResult_C853458A4AEAB1DFEBD030A8777435DA();
	void ExecuteUbergraph_ABP_PetSpectator_MiniTV(int EntryPoint);
};


}

